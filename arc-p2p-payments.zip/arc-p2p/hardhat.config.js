require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: { enabled: true, runs: 200 },
    },
  },
  networks: {
    // Arc Network Testnet
    "arc-testnet": {
      url: "https://rpc.testnet.arc.network",
      chainId: 1234,
      accounts: process.env.PRIVATE_KEY ? [process.env.PRIVATE_KEY] : [],
      gasPrice: "auto",
    },
    // Local for testing
    hardhat: {
      chainId: 31337,
      forking: {
        // Optionally fork Arc testnet for local tests
        enabled: false,
        url: "https://rpc.testnet.arc.network",
      },
    },
  },
  etherscan: {
    apiKey: {
      "arc-testnet": process.env.ARC_EXPLORER_API_KEY || "placeholder",
    },
    customChains: [
      {
        network: "arc-testnet",
        chainId: 1234,
        urls: {
          apiURL: "https://explorer.testnet.arc.network/api",
          browserURL: "https://explorer.testnet.arc.network",
        },
      },
    ],
  },
  paths: {
    sources:   "./contracts",
    tests:     "./test",
    cache:     "./cache",
    artifacts: "./artifacts",
  },
};
