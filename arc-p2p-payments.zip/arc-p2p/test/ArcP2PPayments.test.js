const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

describe("ArcP2PPayments", function () {
  // ─── Fixture ──────────────────────────────────────────────────────────────
  async function deployFixture() {
    const [owner, alice, bob, carol] = await ethers.getSigners();

    // Deploy mock USDC (6 decimals like real USDC)
    const MockUSDC = await ethers.getContractFactory("MockERC20");
    const usdc = await MockUSDC.deploy("USD Coin", "USDC", 6);

    // Deploy P2P contract
    const ArcP2P = await ethers.getContractFactory("ArcP2PPayments");
    const p2p = await ArcP2P.deploy(await usdc.getAddress());

    // Mint USDC to test accounts (1000 USDC each)
    const USDC = (n) => ethers.parseUnits(String(n), 6);
    await usdc.mint(alice.address, USDC(1000));
    await usdc.mint(bob.address,   USDC(1000));
    await usdc.mint(carol.address, USDC(1000));

    // Approve contract to spend USDC
    const p2pAddr = await p2p.getAddress();
    await usdc.connect(alice).approve(p2pAddr, ethers.MaxUint256);
    await usdc.connect(bob).approve(p2pAddr,   ethers.MaxUint256);
    await usdc.connect(carol).approve(p2pAddr, ethers.MaxUint256);

    return { p2p, usdc, owner, alice, bob, carol, USDC };
  }

  // ─── Deployment ───────────────────────────────────────────────────────────
  describe("Deployment", function () {
    it("Sets correct USDC address", async function () {
      const { p2p, usdc } = await loadFixture(deployFixture);
      expect(await p2p.usdc()).to.equal(await usdc.getAddress());
    });

    it("Sets zero protocol fee on deploy", async function () {
      const { p2p } = await loadFixture(deployFixture);
      expect(await p2p.protocolFeeBps()).to.equal(0);
    });

    it("Sets deployer as owner", async function () {
      const { p2p, owner } = await loadFixture(deployFixture);
      expect(await p2p.owner()).to.equal(owner.address);
    });
  });

  // ─── sendPayment ──────────────────────────────────────────────────────────
  describe("sendPayment", function () {
    it("Transfers USDC from sender to recipient", async function () {
      const { p2p, usdc, alice, bob, USDC } = await loadFixture(deployFixture);

      const amount = USDC(100);
      await p2p.connect(alice).sendPayment(bob.address, amount, "Test payment");

      expect(await usdc.balanceOf(bob.address)).to.equal(USDC(1100));
      expect(await usdc.balanceOf(alice.address)).to.equal(USDC(900));
    });

    it("Emits PaymentSent event", async function () {
      const { p2p, alice, bob, USDC } = await loadFixture(deployFixture);
      const amount = USDC(50);

      await expect(
        p2p.connect(alice).sendPayment(bob.address, amount, "coffee ☕")
      )
        .to.emit(p2p, "PaymentSent")
        .withArgs(1, alice.address, bob.address, amount, 0, "coffee ☕", await getTimestamp());
    });

    it("Stores payment record correctly", async function () {
      const { p2p, alice, bob, USDC } = await loadFixture(deployFixture);
      await p2p.connect(alice).sendPayment(bob.address, USDC(200), "rent");

      const payment = await p2p.getPayment(1);
      expect(payment.sender).to.equal(alice.address);
      expect(payment.recipient).to.equal(bob.address);
      expect(payment.amount).to.equal(USDC(200));
      expect(payment.note).to.equal("rent");
      expect(payment.status).to.equal(1); // Completed
    });

    it("Updates totalSent and totalReceived", async function () {
      const { p2p, alice, bob, USDC } = await loadFixture(deployFixture);
      await p2p.connect(alice).sendPayment(bob.address, USDC(300), "");

      const [sent] = await p2p.getUserStats(alice.address);
      const [, received] = await p2p.getUserStats(bob.address);
      expect(sent).to.equal(USDC(300));
      expect(received).to.equal(USDC(300)); // 0 fee
    });

    it("Reverts on zero amount", async function () {
      const { p2p, alice, bob } = await loadFixture(deployFixture);
      await expect(
        p2p.connect(alice).sendPayment(bob.address, 0, "")
      ).to.be.revertedWith("Amount must be > 0");
    });

    it("Reverts on self-transfer", async function () {
      const { p2p, alice, USDC } = await loadFixture(deployFixture);
      await expect(
        p2p.connect(alice).sendPayment(alice.address, USDC(10), "")
      ).to.be.revertedWith("Cannot send to yourself");
    });

    it("Correctly applies protocol fee", async function () {
      const { p2p, usdc, alice, bob, owner, USDC } = await loadFixture(deployFixture);

      await p2p.connect(owner).setFeeBps(50); // 0.5% fee
      const amount = USDC(100);
      const expectedFee = USDC(100) * 50n / 10000n; // 0.05 USDC

      await p2p.connect(alice).sendPayment(bob.address, amount, "");

      // Bob receives amount minus fee
      expect(await usdc.balanceOf(bob.address)).to.equal(USDC(1000) + amount - expectedFee);
    });
  });

  // ─── batchSend ────────────────────────────────────────────────────────────
  describe("batchSend", function () {
    it("Sends to multiple recipients", async function () {
      const { p2p, usdc, alice, bob, carol, USDC } = await loadFixture(deployFixture);

      await p2p.connect(alice).batchSend(
        [bob.address, carol.address],
        [USDC(50), USDC(75)],
        ["split dinner", "taxi"]
      );

      expect(await usdc.balanceOf(bob.address)).to.equal(USDC(1050));
      expect(await usdc.balanceOf(carol.address)).to.equal(USDC(1075));
    });

    it("Reverts on length mismatch", async function () {
      const { p2p, alice, bob, carol, USDC } = await loadFixture(deployFixture);
      await expect(
        p2p.connect(alice).batchSend(
          [bob.address, carol.address],
          [USDC(50)],
          ["note1", "note2"]
        )
      ).to.be.revertedWith("Length mismatch");
    });
  });

  // ─── Payment Requests ─────────────────────────────────────────────────────
  describe("createRequest / fulfillRequest", function () {
    it("Creates a payment request", async function () {
      const { p2p, alice, bob, USDC } = await loadFixture(deployFixture);

      await p2p.connect(alice).createRequest(
        bob.address, USDC(100), "owe me for lunch", 0
      );

      const req = await p2p.getRequest(1);
      expect(req.requester).to.equal(alice.address);
      expect(req.payer).to.equal(bob.address);
      expect(req.amount).to.equal(USDC(100));
      expect(req.status).to.equal(0); // Open
    });

    it("Fulfills a payment request", async function () {
      const { p2p, usdc, alice, bob, USDC } = await loadFixture(deployFixture);

      await p2p.connect(alice).createRequest(bob.address, USDC(100), "lunch", 0);
      await p2p.connect(bob).fulfillRequest(1);

      const req = await p2p.getRequest(1);
      expect(req.status).to.equal(1); // Fulfilled

      expect(await usdc.balanceOf(alice.address)).to.equal(USDC(1100));
      expect(await usdc.balanceOf(bob.address)).to.equal(USDC(900));
    });

    it("Prevents unauthorized fulfillment", async function () {
      const { p2p, alice, bob, carol, USDC } = await loadFixture(deployFixture);

      await p2p.connect(alice).createRequest(bob.address, USDC(100), "", 0);

      await expect(
        p2p.connect(carol).fulfillRequest(1)
      ).to.be.revertedWith("Not authorized");
    });

    it("Cancels own request", async function () {
      const { p2p, alice, bob, USDC } = await loadFixture(deployFixture);

      await p2p.connect(alice).createRequest(bob.address, USDC(100), "", 0);
      await p2p.connect(alice).cancelRequest(1);

      const req = await p2p.getRequest(1);
      expect(req.status).to.equal(2); // Cancelled
    });
  });

  // ─── Admin ────────────────────────────────────────────────────────────────
  describe("Admin", function () {
    it("Owner can update fee", async function () {
      const { p2p, owner } = await loadFixture(deployFixture);
      await p2p.connect(owner).setFeeBps(25);
      expect(await p2p.protocolFeeBps()).to.equal(25);
    });

    it("Reverts if fee > 1%", async function () {
      const { p2p, owner } = await loadFixture(deployFixture);
      await expect(
        p2p.connect(owner).setFeeBps(200)
      ).to.be.revertedWith("Max fee is 1%");
    });

    it("Non-owner cannot set fee", async function () {
      const { p2p, alice } = await loadFixture(deployFixture);
      await expect(
        p2p.connect(alice).setFeeBps(10)
      ).to.be.reverted;
    });

    it("Owner can pause and unpause", async function () {
      const { p2p, owner, alice, bob, USDC } = await loadFixture(deployFixture);

      await p2p.connect(owner).pause();

      await expect(
        p2p.connect(alice).sendPayment(bob.address, USDC(10), "")
      ).to.be.reverted;

      await p2p.connect(owner).unpause();

      await expect(
        p2p.connect(alice).sendPayment(bob.address, USDC(10), "")
      ).to.not.be.reverted;
    });
  });
});

async function getTimestamp() {
  const block = await ethers.provider.getBlock("latest");
  return block.timestamp;
}
