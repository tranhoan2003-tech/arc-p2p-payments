/**
 * useArcP2P — React hook for ARC P2P Payments contract
 *
 * Usage:
 *   const { sendPayment, balance, payments, isLoading } = useArcP2P();
 */

import { useState, useEffect, useCallback } from "react";
import { ethers } from "ethers";

// ─── Constants ──────────────────────────────────────────────────────────────

export const ARC_TESTNET = {
  chainId:     "0x4D2",  // 1234 in hex
  chainName:   "Arc Testnet",
  rpcUrls:     ["https://rpc.testnet.arc.network"],
  nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
  blockExplorerUrls: ["https://explorer.testnet.arc.network"],
};

export const USDC_ADDRESS    = "0x036CbD53842c5426634e7929541eC2318f3dCF7e";
export const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS || "";

const P2P_ABI = [
  "function sendPayment(address recipient, uint256 amount, string note) returns (uint256)",
  "function batchSend(address[] recipients, uint256[] amounts, string[] notes)",
  "function createRequest(address payer, uint256 amount, string note, uint256 deadline) returns (uint256)",
  "function fulfillRequest(uint256 requestId) returns (uint256)",
  "function cancelRequest(uint256 requestId)",
  "function getPayment(uint256) view returns (tuple(uint256 id, address sender, address recipient, uint256 amount, uint256 fee, string note, uint256 timestamp, uint8 status))",
  "function getRequest(uint256) view returns (tuple(uint256 id, address requester, address payer, uint256 amount, string note, uint256 deadline, uint8 status))",
  "function getUserPayments(address) view returns (uint256[])",
  "function getUserRequests(address) view returns (uint256[])",
  "function getUserStats(address) view returns (uint256, uint256, uint256)",
];

const ERC20_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
];

const USDC_DECIMALS = 6;

// ─── Utils ──────────────────────────────────────────────────────────────────

export const toUSDC    = (amount) => ethers.parseUnits(String(amount), USDC_DECIMALS);
export const fromUSDC  = (raw)    => Number(ethers.formatUnits(raw, USDC_DECIMALS));
export const fmtUSDC   = (raw)    => fromUSDC(raw).toLocaleString("vi-VN");

// ─── Hook ────────────────────────────────────────────────────────────────────

export function useArcP2P() {
  const [provider,  setProvider]  = useState(null);
  const [signer,    setSigner]    = useState(null);
  const [address,   setAddress]   = useState(null);
  const [balance,   setBalance]   = useState("0");
  const [payments,  setPayments]  = useState([]);
  const [requests,  setRequests]  = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error,     setError]     = useState(null);

  // ── Connect Wallet ────────────────────────────────────────────────────────
  const connect = useCallback(async () => {
    if (!window.ethereum) {
      setError("Please install MetaMask or a compatible wallet");
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      // Switch to Arc testnet
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: ARC_TESTNET.chainId }],
        });
      } catch (switchErr) {
        if (switchErr.code === 4902) {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [ARC_TESTNET],
          });
        } else throw switchErr;
      }

      const web3Provider = new ethers.BrowserProvider(window.ethereum);
      const web3Signer   = await web3Provider.getSigner();
      const addr         = await web3Signer.getAddress();

      setProvider(web3Provider);
      setSigner(web3Signer);
      setAddress(addr);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // ── Fetch Balance ─────────────────────────────────────────────────────────
  const fetchBalance = useCallback(async () => {
    if (!provider || !address) return;
    try {
      const usdc = new ethers.Contract(USDC_ADDRESS, ERC20_ABI, provider);
      const raw  = await usdc.balanceOf(address);
      setBalance(fromUSDC(raw).toFixed(2));
    } catch (err) {
      console.error("fetchBalance:", err);
    }
  }, [provider, address]);

  // ── Fetch Payments ────────────────────────────────────────────────────────
  const fetchPayments = useCallback(async () => {
    if (!provider || !address || !CONTRACT_ADDRESS) return;
    try {
      const p2p  = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, provider);
      const ids  = await p2p.getUserPayments(address);
      const list = await Promise.all(ids.slice(-20).map(id => p2p.getPayment(id)));

      setPayments(list.reverse().map(p => ({
        id:        p.id.toString(),
        sender:    p.sender,
        recipient: p.recipient,
        amount:    fromUSDC(p.amount),
        fee:       fromUSDC(p.fee),
        note:      p.note,
        timestamp: Number(p.timestamp),
        status:    ["Pending","Completed","Cancelled","Refunded"][p.status],
        isOutgoing: p.sender.toLowerCase() === address.toLowerCase(),
      })));
    } catch (err) {
      console.error("fetchPayments:", err);
    }
  }, [provider, address]);

  // ── Fetch Requests ────────────────────────────────────────────────────────
  const fetchRequests = useCallback(async () => {
    if (!provider || !address || !CONTRACT_ADDRESS) return;
    try {
      const p2p  = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, provider);
      const ids  = await p2p.getUserRequests(address);
      const list = await Promise.all(ids.map(id => p2p.getRequest(id)));

      setRequests(list.map(r => ({
        id:        r.id.toString(),
        requester: r.requester,
        payer:     r.payer === ethers.ZeroAddress ? null : r.payer,
        amount:    fromUSDC(r.amount),
        note:      r.note,
        deadline:  Number(r.deadline),
        status:    ["Open","Fulfilled","Cancelled","Expired"][r.status],
        isMine:    r.requester.toLowerCase() === address.toLowerCase(),
      })));
    } catch (err) {
      console.error("fetchRequests:", err);
    }
  }, [provider, address]);

  // ── Ensure USDC Approval ──────────────────────────────────────────────────
  const ensureApproval = async (amount) => {
    const usdc      = new ethers.Contract(USDC_ADDRESS, ERC20_ABI, signer);
    const allowance = await usdc.allowance(address, CONTRACT_ADDRESS);

    if (allowance < amount) {
      const tx = await usdc.approve(CONTRACT_ADDRESS, ethers.MaxUint256);
      await tx.wait();
    }
  };

  // ── Send Payment ──────────────────────────────────────────────────────────
  const sendPayment = useCallback(async (recipient, amount, note = "") => {
    if (!signer || !CONTRACT_ADDRESS) throw new Error("Not connected");

    setIsLoading(true);
    setError(null);

    try {
      const amountRaw = toUSDC(amount);
      await ensureApproval(amountRaw);

      const p2p = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, signer);
      const tx  = await p2p.sendPayment(recipient, amountRaw, note);
      const receipt = await tx.wait();

      await Promise.all([fetchBalance(), fetchPayments()]);

      return {
        txHash:    receipt.hash,
        blockNumber: receipt.blockNumber,
        explorerUrl: `https://explorer.testnet.arc.network/tx/${receipt.hash}`,
      };
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [signer, address, fetchBalance, fetchPayments]);

  // ── Batch Send ────────────────────────────────────────────────────────────
  const batchSend = useCallback(async (recipients, amounts, notes) => {
    if (!signer || !CONTRACT_ADDRESS) throw new Error("Not connected");

    setIsLoading(true);
    try {
      const totalAmount = amounts.reduce((s, a) => s + toUSDC(a), 0n);
      await ensureApproval(totalAmount);

      const p2p = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, signer);
      const tx  = await p2p.batchSend(
        recipients,
        amounts.map(a => toUSDC(a)),
        notes
      );
      const receipt = await tx.wait();
      await Promise.all([fetchBalance(), fetchPayments()]);
      return receipt;
    } finally {
      setIsLoading(false);
    }
  }, [signer, address, fetchBalance, fetchPayments]);

  // ── Create Request ────────────────────────────────────────────────────────
  const createRequest = useCallback(async (payer, amount, note, deadlineDays = 0) => {
    if (!signer || !CONTRACT_ADDRESS) throw new Error("Not connected");

    setIsLoading(true);
    try {
      const deadline = deadlineDays > 0
        ? Math.floor(Date.now() / 1000) + deadlineDays * 86400
        : 0;

      const p2p = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, signer);
      const tx  = await p2p.createRequest(
        payer || ethers.ZeroAddress,
        toUSDC(amount),
        note,
        deadline
      );
      const receipt = await tx.wait();
      await fetchRequests();
      return receipt;
    } finally {
      setIsLoading(false);
    }
  }, [signer, fetchRequests]);

  // ── Fulfill Request ───────────────────────────────────────────────────────
  const fulfillRequest = useCallback(async (requestId, amount) => {
    if (!signer || !CONTRACT_ADDRESS) throw new Error("Not connected");

    setIsLoading(true);
    try {
      await ensureApproval(toUSDC(amount));

      const p2p = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, signer);
      const tx  = await p2p.fulfillRequest(requestId);
      const receipt = await tx.wait();
      await Promise.all([fetchBalance(), fetchPayments(), fetchRequests()]);
      return receipt;
    } finally {
      setIsLoading(false);
    }
  }, [signer, address, fetchBalance, fetchPayments, fetchRequests]);

  // ── Auto-refresh ──────────────────────────────────────────────────────────
  useEffect(() => {
    if (address) {
      fetchBalance();
      fetchPayments();
      fetchRequests();

      const interval = setInterval(() => {
        fetchBalance();
      }, 15_000); // refresh balance every 15s

      return () => clearInterval(interval);
    }
  }, [address, fetchBalance, fetchPayments, fetchRequests]);

  // ── Account change listener ───────────────────────────────────────────────
  useEffect(() => {
    if (!window.ethereum) return;
    const handleAccountsChanged = (accounts) => {
      if (accounts.length === 0) {
        setAddress(null);
        setSigner(null);
      } else {
        connect();
      }
    };
    window.ethereum.on("accountsChanged", handleAccountsChanged);
    return () => window.ethereum.removeListener("accountsChanged", handleAccountsChanged);
  }, [connect]);

  return {
    // State
    address, balance, payments, requests, isLoading, error,
    isConnected: !!address,
    // Actions
    connect, sendPayment, batchSend, createRequest, fulfillRequest,
    // Utils
    refresh: () => Promise.all([fetchBalance(), fetchPayments(), fetchRequests()]),
  };
}
