# ARC P2P Payments

> Peer-to-peer USDC payments built natively on Arc Network — the Economic OS for the internet.

[![Arc Testnet](https://img.shields.io/badge/Arc-Testnet-1D9E75?style=flat-square)](https://arc.network)
[![Solidity](https://img.shields.io/badge/Solidity-0.8.20-blue?style=flat-square)](https://soliditylang.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)](LICENSE)

---

## What is this?

ARC P2P Payments is a decentralized peer-to-peer payment application built on **Arc Network** — Circle's stablecoin-native L1 blockchain. It enables instant USDC transfers between any two wallets with zero protocol fees, sub-second finality, and full on-chain transparency.

This project was built as a contribution to the **Arc Network Architects program**.

---

## Why Arc Network?

Arc is uniquely suited for P2P payments because:

- **USDC-denominated gas fees** — users pay in dollars, not volatile crypto
- **Sub-second transaction finality** — payments feel instant
- **Native USDC integration** — no wrapping, bridging, or complexity
- **EVM-compatible** — familiar Solidity tooling, easy wallet integration
- **Opt-in privacy** — configurable confidential balances for sensitive payments

---

## Features

### Smart Contract (`ArcP2PPayments.sol`)
- ✅ Direct USDC transfer between any two wallets
- ✅ Batch payments — split bills, payroll (up to 20 recipients in one tx)
- ✅ Payment requests — request money from specific address or open request
- ✅ On-chain payment history with notes/memos
- ✅ Zero protocol fee (free P2P on Arc!)
- ✅ Emergency pause (owner only)
- ✅ Reentrancy protection
- ✅ Full test coverage (Hardhat + Chai)

### Backend API (Express + ethers.js)
- `GET /health` — network status
- `GET /api/user/:address/stats` — sent/received totals, USDC balance
- `GET /api/user/:address/payments` — paginated payment history
- `GET /api/user/:address/requests` — all payment requests
- `GET /api/payment/:id` — single payment details
- `GET /api/request/:id` — single request details
- `GET /api/stats/global` — protocol-wide volume stats
- `POST /api/estimate` — gas estimation before tx

### Frontend (Next.js + React)
- Wallet connection (MetaMask, auto-switch to Arc testnet)
- Dashboard with real USDC balance
- Send payment flow (3-step: select → amount → confirm)
- Receive via QR code + wallet address
- Payment requests (create, fulfill, cancel)
- Full transaction history
- Batch send for splitting expenses

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│                   Frontend (Next.js)             │
│   useArcP2P hook ←→ MetaMask / WalletConnect    │
└──────────────────────┬──────────────────────────┘
                       │ ethers.js (direct RPC)
         ┌─────────────▼──────────────┐
         │    Arc Network Testnet      │
         │   Chain ID: 1234            │
         │   RPC: rpc.testnet.arc.network │
         └─────────────┬──────────────┘
                       │
         ┌─────────────▼──────────────┐
         │   ArcP2PPayments.sol        │
         │   (Solidity 0.8.20)         │
         │   ├─ sendPayment()          │
         │   ├─ batchSend()            │
         │   ├─ createRequest()        │
         │   └─ fulfillRequest()       │
         └─────────────┬──────────────┘
                       │ reads
         ┌─────────────▼──────────────┐
         │   Backend API (Express)     │
         │   Read-only indexer         │
         │   Serves paginated history  │
         └────────────────────────────┘
```

---

## Quick Start

### Prerequisites
- Node.js ≥ 18
- MetaMask or compatible EVM wallet
- Arc Testnet USDC from [faucet.testnet.arc.network](https://faucet.testnet.arc.network)

### 1. Clone & install

```bash
git clone https://github.com/yourusername/arc-p2p-payments
cd arc-p2p-payments
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env`:
```env
# Your wallet private key (for deployment only — NEVER commit this)
PRIVATE_KEY=your_private_key_here

# After deployment, fill this in:
NEXT_PUBLIC_CONTRACT_ADDRESS=0x...

# Arc Testnet RPC
ARC_RPC_URL=https://rpc.testnet.arc.network

# Backend
PORT=3001
FRONTEND_URL=http://localhost:3000
```

### 3. Run tests

```bash
npx hardhat test
```

Expected output:
```
  ArcP2PPayments
    Deployment
      ✔ Sets correct USDC address
      ✔ Sets zero protocol fee on deploy
      ✔ Sets deployer as owner
    sendPayment
      ✔ Transfers USDC from sender to recipient
      ✔ Emits PaymentSent event
      ✔ Stores payment record correctly
      ✔ Updates totalSent and totalReceived
      ✔ Reverts on zero amount
      ✔ Reverts on self-transfer
      ✔ Correctly applies protocol fee
    batchSend
      ✔ Sends to multiple recipients
      ✔ Reverts on length mismatch
    createRequest / fulfillRequest
      ✔ Creates a payment request
      ✔ Fulfills a payment request
      ✔ Prevents unauthorized fulfillment
      ✔ Cancels own request
    Admin
      ✔ Owner can update fee
      ✔ Reverts if fee > 1%
      ✔ Non-owner cannot set fee
      ✔ Owner can pause and unpause

  20 passing (2s)
```

### 4. Deploy to Arc Testnet

```bash
npx hardhat run scripts/deploy.js --network arc-testnet
```

### 5. Start backend

```bash
cd backend
npm install
npm start
```

### 6. Start frontend

```bash
cd frontend
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Arc Network Configuration

| Field | Value |
|---|---|
| Network Name | Arc Testnet |
| Chain ID | 1234 |
| RPC URL | https://rpc.testnet.arc.network |
| USDC Address | 0x036CbD53842c5426634e7929541eC2318f3dCF7e |
| Block Explorer | https://explorer.testnet.arc.network |
| Faucet | https://faucet.testnet.arc.network |

---

## Contract Addresses (Testnet)

| Contract | Address |
|---|---|
| ArcP2PPayments | TBD after deployment |
| USDC (Circle) | 0x036CbD53842c5426634e7929541eC2318f3dCF7e |

---

## Roadmap

- [ ] WalletConnect integration (mobile wallets)
- [ ] EURC support (Euro stablecoin)
- [ ] Recurring payments (subscription model)
- [ ] On-chain notifications via events
- [ ] Multi-chain via Circle CCTP (cross-chain USDC)
- [ ] Arc mainnet deployment

---

## Contributing

This project is part of the **Arc Network Architects** community program. Contributions, feedback, and forks are welcome!

1. Fork the repo
2. Create your branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'feat: add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## License

MIT © 2026 — Built with ❤️ on Arc Network
