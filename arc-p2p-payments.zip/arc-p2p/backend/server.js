/**
 * ARC P2P Payments — Backend API
 * Node.js + Express + ethers.js
 *
 * Endpoints:
 *   GET  /health
 *   GET  /api/user/:address/stats
 *   GET  /api/user/:address/payments
 *   GET  /api/user/:address/requests
 *   GET  /api/payment/:id
 *   GET  /api/request/:id
 *   GET  /api/stats/global
 *   POST /api/estimate   (estimate gas before tx)
 */

const express  = require("express");
const cors     = require("cors");
const helmet   = require("helmet");
const { ethers } = require("ethers");
require("dotenv").config();

// ─── Config ──────────────────────────────────────────────────────────────────

const PORT             = process.env.PORT || 3001;
const ARC_RPC          = process.env.ARC_RPC_URL || "https://rpc.testnet.arc.network";
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS;
const USDC_ADDRESS     = process.env.USDC_ADDRESS || "0x036CbD53842c5426634e7929541eC2318f3dCF7e";

// Minimal ABI for read-only operations
const P2P_ABI = [
  "function getPayment(uint256) view returns (tuple(uint256 id, address sender, address recipient, uint256 amount, uint256 fee, string note, uint256 timestamp, uint8 status))",
  "function getRequest(uint256) view returns (tuple(uint256 id, address requester, address payer, uint256 amount, string note, uint256 deadline, uint8 status))",
  "function getUserPayments(address) view returns (uint256[])",
  "function getUserRequests(address) view returns (uint256[])",
  "function getUserStats(address) view returns (uint256 sent, uint256 received, uint256 paymentCount)",
  "function totalVolume() view returns (uint256)",
  "function totalFeesCollected() view returns (uint256)",
  "function protocolFeeBps() view returns (uint256)",
  // Events
  "event PaymentSent(uint256 indexed paymentId, address indexed sender, address indexed recipient, uint256 amount, uint256 fee, string note, uint256 timestamp)",
  "event RequestCreated(uint256 indexed requestId, address indexed requester, address indexed payer, uint256 amount, string note, uint256 deadline)",
];

const USDC_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function decimals() view returns (uint8)",
];

// ─── Provider & Contracts ─────────────────────────────────────────────────

const provider = new ethers.JsonRpcProvider(ARC_RPC);
let p2pContract = null;
let usdcContract = null;

function getContracts() {
  if (!p2pContract && CONTRACT_ADDRESS) {
    p2pContract  = new ethers.Contract(CONTRACT_ADDRESS, P2P_ABI, provider);
    usdcContract = new ethers.Contract(USDC_ADDRESS, USDC_ABI, provider);
  }
  return { p2p: p2pContract, usdc: usdcContract };
}

// ─── Helpers ─────────────────────────────────────────────────────────────

const USDC_DECIMALS = 6;
const formatUSDC = (raw) => (Number(raw) / 10 ** USDC_DECIMALS).toFixed(2);

const PAYMENT_STATUS = ["Pending", "Completed", "Cancelled", "Refunded"];
const REQUEST_STATUS = ["Open", "Fulfilled", "Cancelled", "Expired"];

function formatPayment(p) {
  return {
    id:        p.id.toString(),
    sender:    p.sender,
    recipient: p.recipient,
    amount:    formatUSDC(p.amount),
    amountRaw: p.amount.toString(),
    fee:       formatUSDC(p.fee),
    note:      p.note,
    timestamp: Number(p.timestamp),
    date:      new Date(Number(p.timestamp) * 1000).toISOString(),
    status:    PAYMENT_STATUS[p.status] || "Unknown",
  };
}

function formatRequest(r) {
  return {
    id:        r.id.toString(),
    requester: r.requester,
    payer:     r.payer === ethers.ZeroAddress ? null : r.payer,
    amount:    formatUSDC(r.amount),
    amountRaw: r.amount.toString(),
    note:      r.note,
    deadline:  Number(r.deadline),
    deadlineDate: r.deadline > 0 ? new Date(Number(r.deadline) * 1000).toISOString() : null,
    status:    REQUEST_STATUS[r.status] || "Unknown",
  };
}

// ─── App ─────────────────────────────────────────────────────────────────────

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());

// ─── Request Logger ───────────────────────────────────────────────────────

app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ─── Routes ───────────────────────────────────────────────────────────────

app.get("/health", async (req, res) => {
  try {
    const block = await provider.getBlockNumber();
    res.json({
      status: "ok",
      network: "arc-testnet",
      block,
      contract: CONTRACT_ADDRESS || "not configured",
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(503).json({ status: "error", message: err.message });
  }
});

// User stats + USDC balance
app.get("/api/user/:address/stats", async (req, res) => {
  try {
    const { address } = req.params;
    if (!ethers.isAddress(address)) {
      return res.status(400).json({ error: "Invalid Ethereum address" });
    }

    const { p2p, usdc } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const [stats, usdcBalance] = await Promise.all([
      p2p.getUserStats(address),
      usdc.balanceOf(address),
    ]);

    res.json({
      address,
      totalSent:      formatUSDC(stats.sent),
      totalReceived:  formatUSDC(stats.received),
      paymentCount:   Number(stats.paymentCount),
      usdcBalance:    formatUSDC(usdcBalance),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// All payments for a user (paginated)
app.get("/api/user/:address/payments", async (req, res) => {
  try {
    const { address } = req.params;
    const page  = Math.max(1, parseInt(req.query.page  || "1"));
    const limit = Math.min(50, parseInt(req.query.limit || "20"));

    if (!ethers.isAddress(address)) {
      return res.status(400).json({ error: "Invalid address" });
    }

    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const ids = await p2p.getUserPayments(address);
    const total = ids.length;

    // Paginate (newest first)
    const reversed  = [...ids].reverse();
    const pageIds   = reversed.slice((page - 1) * limit, page * limit);
    const payments  = await Promise.all(pageIds.map(id => p2p.getPayment(id)));

    res.json({
      data:  payments.map(formatPayment),
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// All requests for a user
app.get("/api/user/:address/requests", async (req, res) => {
  try {
    const { address } = req.params;
    if (!ethers.isAddress(address)) {
      return res.status(400).json({ error: "Invalid address" });
    }

    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const ids     = await p2p.getUserRequests(address);
    const requests = await Promise.all(ids.map(id => p2p.getRequest(id)));

    res.json({
      data:  requests.map(formatRequest),
      total: ids.length,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Single payment
app.get("/api/payment/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id < 1) {
      return res.status(400).json({ error: "Invalid payment ID" });
    }

    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const payment = await p2p.getPayment(id);
    if (payment.id === 0n) return res.status(404).json({ error: "Payment not found" });

    res.json(formatPayment(payment));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Single request
app.get("/api/request/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id) || id < 1) {
      return res.status(400).json({ error: "Invalid request ID" });
    }

    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const request = await p2p.getRequest(id);
    if (request.id === 0n) return res.status(404).json({ error: "Request not found" });

    res.json(formatRequest(request));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Global protocol stats
app.get("/api/stats/global", async (req, res) => {
  try {
    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const [volume, fees, feeBps, block] = await Promise.all([
      p2p.totalVolume(),
      p2p.totalFeesCollected(),
      p2p.protocolFeeBps(),
      provider.getBlockNumber(),
    ]);

    res.json({
      totalVolumeUSDC: formatUSDC(volume),
      totalFeesUSDC:   formatUSDC(fees),
      protocolFeeBps:  Number(feeBps),
      isFree:          Number(feeBps) === 0,
      latestBlock:     block,
      network:         "arc-testnet",
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Estimate gas for a send
app.post("/api/estimate", async (req, res) => {
  try {
    const { from, to, amount, note = "" } = req.body;

    if (!ethers.isAddress(from) || !ethers.isAddress(to)) {
      return res.status(400).json({ error: "Invalid addresses" });
    }

    const { p2p } = getContracts();
    if (!p2p) return res.status(503).json({ error: "Contract not configured" });

    const amountUnits = ethers.parseUnits(String(amount), USDC_DECIMALS);

    const gasEstimate = await p2p.sendPayment.estimateGas(to, amountUnits, note, {
      from,
    });

    const feeData = await provider.getFeeData();

    res.json({
      gasEstimate:    gasEstimate.toString(),
      gasPrice:       feeData.gasPrice?.toString(),
      maxFeePerGas:   feeData.maxFeePerGas?.toString(),
      estimatedCostWei: (gasEstimate * (feeData.maxFeePerGas || feeData.gasPrice || 0n)).toString(),
      note: "Gas paid in USDC on Arc Network (not ETH)",
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── 404 ──────────────────────────────────────────────────────────────────

app.use((req, res) => {
  res.status(404).json({ error: "Not found", path: req.path });
});

// ─── Start ────────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`
  ╔═══════════════════════════════════╗
  ║   ARC P2P Payments — API Server   ║
  ╠═══════════════════════════════════╣
  ║  Port:    ${PORT}                     ║
  ║  Network: Arc Testnet             ║
  ║  RPC:     ${ARC_RPC.slice(0, 28)}...  ║
  ╚═══════════════════════════════════╝
  `);
});

module.exports = app;
