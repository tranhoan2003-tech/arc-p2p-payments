// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title ArcP2PPayments
 * @author ARC Network Builder
 * @notice Peer-to-peer payment contract on Arc Network using USDC
 * @dev Supports direct transfers, payment requests, and escrow payments
 *
 * Arc Network Testnet:
 *   RPC: https://rpc.testnet.arc.network
 *   Chain ID: 1234 (testnet)
 *   USDC: 0x036CbD53842c5426634e7929541eC2318f3dCF7e (Arc testnet USDC)
 */
contract ArcP2PPayments is Ownable, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    // ─── State ───────────────────────────────────────────────────────────────

    IERC20 public immutable usdc;

    uint256 public constant FEE_DENOMINATOR = 10_000;
    uint256 public protocolFeeBps = 0; // 0% fee — free P2P on Arc!

    uint256 private _paymentIdCounter;
    uint256 private _requestIdCounter;

    // ─── Structs ─────────────────────────────────────────────────────────────

    enum PaymentStatus { Pending, Completed, Cancelled, Refunded }
    enum RequestStatus { Open, Fulfilled, Cancelled, Expired }

    struct Payment {
        uint256 id;
        address sender;
        address recipient;
        uint256 amount;
        uint256 fee;
        string  note;
        uint256 timestamp;
        PaymentStatus status;
    }

    struct PaymentRequest {
        uint256 id;
        address requester;
        address payer;         // address(0) = open to anyone
        uint256 amount;
        string  note;
        uint256 deadline;
        RequestStatus status;
    }

    // ─── Storage ─────────────────────────────────────────────────────────────

    mapping(uint256 => Payment)        public payments;
    mapping(uint256 => PaymentRequest) public paymentRequests;

    // user address => list of payment IDs (sent + received)
    mapping(address => uint256[]) public userPayments;
    mapping(address => uint256[]) public userRequests;

    // total stats
    mapping(address => uint256) public totalSent;
    mapping(address => uint256) public totalReceived;

    uint256 public totalVolume;
    uint256 public totalFeesCollected;

    // ─── Events ──────────────────────────────────────────────────────────────

    event PaymentSent(
        uint256 indexed paymentId,
        address indexed sender,
        address indexed recipient,
        uint256 amount,
        uint256 fee,
        string  note,
        uint256 timestamp
    );

    event PaymentRefunded(uint256 indexed paymentId);

    event RequestCreated(
        uint256 indexed requestId,
        address indexed requester,
        address indexed payer,
        uint256 amount,
        string  note,
        uint256 deadline
    );

    event RequestFulfilled(
        uint256 indexed requestId,
        uint256 indexed paymentId,
        address indexed payer
    );

    event RequestCancelled(uint256 indexed requestId);

    event FeeBpsUpdated(uint256 oldBps, uint256 newBps);
    event FeesWithdrawn(address indexed to, uint256 amount);

    // ─── Constructor ─────────────────────────────────────────────────────────

    constructor(address _usdc) Ownable(msg.sender) {
        require(_usdc != address(0), "Invalid USDC address");
        usdc = IERC20(_usdc);
    }

    // ─── Core: Send Payment ───────────────────────────────────────────────────

    /**
     * @notice Send USDC directly to another address
     * @param recipient   Destination wallet
     * @param amount      Amount in USDC micro-units (6 decimals)
     * @param note        Optional memo (max 280 chars)
     */
    function sendPayment(
        address recipient,
        uint256 amount,
        string calldata note
    )
        external
        nonReentrant
        whenNotPaused
        returns (uint256 paymentId)
    {
        require(recipient != address(0), "Invalid recipient");
        require(recipient != msg.sender,  "Cannot send to yourself");
        require(amount > 0,               "Amount must be > 0");
        require(bytes(note).length <= 280, "Note too long");

        uint256 fee = _calculateFee(amount);
        uint256 netAmount = amount - fee;

        paymentId = ++_paymentIdCounter;

        payments[paymentId] = Payment({
            id:        paymentId,
            sender:    msg.sender,
            recipient: recipient,
            amount:    amount,
            fee:       fee,
            note:      note,
            timestamp: block.timestamp,
            status:    PaymentStatus.Completed
        });

        userPayments[msg.sender].push(paymentId);
        userPayments[recipient].push(paymentId);

        totalSent[msg.sender]   += amount;
        totalReceived[recipient] += netAmount;
        totalVolume              += amount;
        totalFeesCollected       += fee;

        // Transfer: sender → contract (fee) + recipient (net)
        usdc.safeTransferFrom(msg.sender, recipient, netAmount);
        if (fee > 0) {
            usdc.safeTransferFrom(msg.sender, address(this), fee);
        }

        emit PaymentSent(
            paymentId, msg.sender, recipient,
            amount, fee, note, block.timestamp
        );
    }

    /**
     * @notice Batch send to multiple recipients in one tx
     * @dev Gas-efficient for payroll / splitting bills
     */
    function batchSend(
        address[] calldata recipients,
        uint256[] calldata amounts,
        string[]  calldata notes
    ) external nonReentrant whenNotPaused {
        require(recipients.length == amounts.length, "Length mismatch");
        require(recipients.length == notes.length,   "Length mismatch");
        require(recipients.length <= 20,             "Max 20 recipients");

        for (uint256 i = 0; i < recipients.length; i++) {
            // Re-use sendPayment logic via internal path
            _sendInternal(recipients[i], amounts[i], notes[i]);
        }
    }

    // ─── Core: Payment Requests ───────────────────────────────────────────────

    /**
     * @notice Request payment from a specific address (or anyone)
     * @param payer     Target payer address (address(0) = open request)
     * @param amount    USDC amount requested
     * @param note      Reason for the request
     * @param deadline  Unix timestamp deadline (0 = no deadline)
     */
    function createRequest(
        address payer,
        uint256 amount,
        string calldata note,
        uint256 deadline
    )
        external
        whenNotPaused
        returns (uint256 requestId)
    {
        require(amount > 0, "Amount must be > 0");
        require(deadline == 0 || deadline > block.timestamp, "Invalid deadline");

        requestId = ++_requestIdCounter;

        paymentRequests[requestId] = PaymentRequest({
            id:        requestId,
            requester: msg.sender,
            payer:     payer,
            amount:    amount,
            note:      note,
            deadline:  deadline,
            status:    RequestStatus.Open
        });

        userRequests[msg.sender].push(requestId);
        if (payer != address(0)) userRequests[payer].push(requestId);

        emit RequestCreated(requestId, msg.sender, payer, amount, note, deadline);
    }

    /**
     * @notice Fulfill an open payment request
     */
    function fulfillRequest(uint256 requestId)
        external
        nonReentrant
        whenNotPaused
        returns (uint256 paymentId)
    {
        PaymentRequest storage req = paymentRequests[requestId];

        require(req.id != 0,                              "Request not found");
        require(req.status == RequestStatus.Open,         "Request not open");
        require(req.payer == address(0) || req.payer == msg.sender, "Not authorized");
        require(req.deadline == 0 || block.timestamp <= req.deadline, "Expired");

        req.status = RequestStatus.Fulfilled;

        paymentId = _sendInternal(req.requester, req.amount, req.note);

        emit RequestFulfilled(requestId, paymentId, msg.sender);
    }

    /**
     * @notice Cancel your own request
     */
    function cancelRequest(uint256 requestId) external {
        PaymentRequest storage req = paymentRequests[requestId];
        require(req.requester == msg.sender, "Not the requester");
        require(req.status == RequestStatus.Open, "Not open");

        req.status = RequestStatus.Cancelled;
        emit RequestCancelled(requestId);
    }

    // ─── Views ────────────────────────────────────────────────────────────────

    function getUserPayments(address user)
        external view returns (uint256[] memory)
    {
        return userPayments[user];
    }

    function getUserRequests(address user)
        external view returns (uint256[] memory)
    {
        return userRequests[user];
    }

    function getPayment(uint256 paymentId)
        external view returns (Payment memory)
    {
        return payments[paymentId];
    }

    function getRequest(uint256 requestId)
        external view returns (PaymentRequest memory)
    {
        return paymentRequests[requestId];
    }

    function getUserStats(address user)
        external view
        returns (uint256 sent, uint256 received, uint256 paymentCount)
    {
        return (
            totalSent[user],
            totalReceived[user],
            userPayments[user].length
        );
    }

    // ─── Admin ────────────────────────────────────────────────────────────────

    function setFeeBps(uint256 newBps) external onlyOwner {
        require(newBps <= 100, "Max fee is 1%");
        emit FeeBpsUpdated(protocolFeeBps, newBps);
        protocolFeeBps = newBps;
    }

    function withdrawFees(address to) external onlyOwner {
        uint256 balance = usdc.balanceOf(address(this));
        require(balance > 0, "Nothing to withdraw");
        usdc.safeTransfer(to, balance);
        emit FeesWithdrawn(to, balance);
    }

    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ─── Internal ────────────────────────────────────────────────────────────

    function _sendInternal(
        address recipient,
        uint256 amount,
        string memory note
    ) internal returns (uint256 paymentId) {
        require(recipient != address(0), "Invalid recipient");
        require(amount > 0, "Amount must be > 0");

        uint256 fee = _calculateFee(amount);
        uint256 netAmount = amount - fee;

        paymentId = ++_paymentIdCounter;

        payments[paymentId] = Payment({
            id:        paymentId,
            sender:    msg.sender,
            recipient: recipient,
            amount:    amount,
            fee:       fee,
            note:      note,
            timestamp: block.timestamp,
            status:    PaymentStatus.Completed
        });

        userPayments[msg.sender].push(paymentId);
        userPayments[recipient].push(paymentId);

        totalSent[msg.sender]    += amount;
        totalReceived[recipient]  += netAmount;
        totalVolume               += amount;
        totalFeesCollected        += fee;

        usdc.safeTransferFrom(msg.sender, recipient, netAmount);
        if (fee > 0) {
            usdc.safeTransferFrom(msg.sender, address(this), fee);
        }

        emit PaymentSent(
            paymentId, msg.sender, recipient,
            amount, fee, note, block.timestamp
        );
    }

    function _calculateFee(uint256 amount) internal view returns (uint256) {
        return (amount * protocolFeeBps) / FEE_DENOMINATOR;
    }
}
