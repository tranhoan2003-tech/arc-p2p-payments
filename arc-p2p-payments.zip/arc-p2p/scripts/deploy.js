// scripts/deploy.js
const { ethers } = require("hardhat");

// Arc Network Testnet USDC address
// Faucet: https://faucet.testnet.arc.network
const ARC_TESTNET_USDC = "0x036CbD53842c5426634e7929541eC2318f3dCF7e";

async function main() {
  const [deployer] = await ethers.getSigners();

  console.log("═══════════════════════════════════════");
  console.log("   ARC P2P Payments — Deploy Script    ");
  console.log("═══════════════════════════════════════");
  console.log("Deployer:", deployer.address);
  console.log("Network: ", (await ethers.provider.getNetwork()).name);

  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("Balance: ", ethers.formatEther(balance), "ETH (for gas)");
  console.log("───────────────────────────────────────");

  // Deploy contract
  console.log("\n⏳ Deploying ArcP2PPayments...");
  const ArcP2P = await ethers.getContractFactory("ArcP2PPayments");
  const contract = await ArcP2P.deploy(ARC_TESTNET_USDC);
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log("✅ ArcP2PPayments deployed to:", address);

  // Verify deployment
  const usdc = await contract.usdc();
  const owner = await contract.owner();
  const feeBps = await contract.protocolFeeBps();

  console.log("\n📋 Contract Info:");
  console.log("   USDC address:  ", usdc);
  console.log("   Owner:         ", owner);
  console.log("   Protocol fee:  ", feeBps.toString(), "bps (0% = free!)");

  console.log("\n═══════════════════════════════════════");
  console.log("🎉 Deployment complete!");
  console.log("\nNext steps:");
  console.log("1. Verify on Arc Explorer:");
  console.log("   https://explorer.testnet.arc.network/address/" + address);
  console.log("2. Update .env:");
  console.log("   NEXT_PUBLIC_CONTRACT_ADDRESS=" + address);
  console.log("3. Get testnet USDC from faucet:");
  console.log("   https://faucet.testnet.arc.network");
  console.log("═══════════════════════════════════════");

  // Save deployment info
  const fs = require("fs");
  const deploymentInfo = {
    network: "arc-testnet",
    chainId: 1234,
    contractAddress: address,
    usdc: ARC_TESTNET_USDC,
    deployer: deployer.address,
    deployedAt: new Date().toISOString(),
    blockNumber: await ethers.provider.getBlockNumber(),
  };

  fs.writeFileSync(
    "./deployments/arc-testnet.json",
    JSON.stringify(deploymentInfo, null, 2)
  );
  console.log("\n💾 Saved to deployments/arc-testnet.json");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("❌ Deploy failed:", err);
    process.exit(1);
  });
